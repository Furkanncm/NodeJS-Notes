const { Pool } = require('pg');//PostgreSQL modülünün Pool sinifi veritabanı bağlantılarını etkin bir şekilde yönetmek
const pool = new Pool({//yeni bir Pool nesnesi oluşturuyoruz
    user: 'postgres',//veritabanına bağlan
    host: 'localhost',//sunucusunun konumunu
    database: 'mydb',//veritabanının adını
    password: 'zxcv',//veritabani sifersi
    port: 5432//veritabanına bağlanmak için kullanılan port numarasını
})

module.exports = pool;