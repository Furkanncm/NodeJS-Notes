const bodyParser = require("body-parser");//gelen isteklerin gövdelerini ayrıştırir. 
const express = require("express");//yonlendirme isteklerini icerecek
const ogrenciRouter = require("./ogrenci");
const bolumRouter = require("./bolum");

const app = express();
const port = 3000;//bu porta dinlenecek

app.use(bodyParser.json());//aciklama

app.use("/ogrenci",ogrenciRouter);//  /ogrenci altındaki isteklerin ogrenciRouter a yönlendirilece.
app.use("/bolum",bolumRouter);

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);//dinleniyor
});